Ovrdrive
--------
Size :	36.6 x 15 mm
Layer : 4 Layers
Material : FR-4: TG150
Thickness : 0.6 mm
Min track/spacing : 4/4mil
Min hole size : 0.2mm
Solder mask : Black
Silkscreen : White
Edge connector : No
Surface finish : HASL lead free
Via process : Tenting vias
Finished copper : 1 oz Cu (Inner Copper:1 oz)
Remove product No. : Yes

Update From R0.41
----------------
1) Changed board outline to fit in enclosure better
2) Rotated TC2030
